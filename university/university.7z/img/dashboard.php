<html>
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Vice Chancellor</title>
		  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
		  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		  <link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
		  <link href="layout1.css" rel="stylesheet" type="text/css" media="all">
    
    </head>
    <body class="w3-amber" style="max-width:1600px">
	
	 <div class="container-fluid">
            <div class="responsive">
			
		       <div class="col-row" style="height:100px; background-color:#FF7F50">
			   <div class="row">
						<div class="col-sm-4">
						<img src="img/universitylogo4.png" class="img-responsive">
						</div>
						<div class="col-sm-8">
						<h4><b class="w3-text-white">UNIVERSITY</b></h4>
						</div>
				</div>
			  
			</div>
		</div>
    </div>		
   </body>
</html>