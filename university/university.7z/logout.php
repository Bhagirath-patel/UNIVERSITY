<?php
    setCookie("email","",time()-1);
	header("location:login.php");

?>